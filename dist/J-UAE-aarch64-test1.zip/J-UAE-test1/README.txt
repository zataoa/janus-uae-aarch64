Janus-UAE for AArch64 AROS: test 1
==================================

This is the first build of Janus-UAE for the Raspberry Pi 64-bit AROS.
It has never been run before. It may fail straight away. That is fine.
Test 1 only asks one question: does it start?

What is in this folder
----------------------
J-UAE                    the program
Configurations/          a default configuration file
README.txt               this file

There is no Kickstart ROM here. Do not add one yet.

What to do
----------
1. Copy the whole folder J-UAE-test1 to your AROS drive.
   For example to Work: or RAM:.
2. Open a Shell and go into the folder:
       CD Work:J-UAE-test1
3. Type this and press Return:
       Stack 262144
4. Type this and press Return:
       J-UAE
5. Look at what happens. Do not press anything else for about a minute.

What to send back
-----------------
Send a screenshot of the screen, or copy the exact text from the Shell.
The exact text matters most. Please include any line that starts with
"Couldn't open", "Error", "Guru" or "Software Failure".

Possible results, so you know what to expect
--------------------------------------------
A. A settings window opens. That is a good result.
B. The Shell says a library could not be opened. Send me the library name.
C. The machine freezes or reboots. Tell me what you last saw.
D. Nothing happens. Tell me that too.

Notes
-----
This build was made with the AROS GCC 6.5.0 cross compiler from the
mainline AROS source. It uses the plain interpreted 68k CPU core.
There is no JIT, no sound and no Janus integration in this build.
